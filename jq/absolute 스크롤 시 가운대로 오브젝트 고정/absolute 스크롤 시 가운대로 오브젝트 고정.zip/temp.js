window.onload= function(){
	

	
	
	

}

var lastScrollLeft = 0;
$(window).scroll(function() {
	var documentScrollLeft = $(document).scrollLeft();
	if (lastScrollLeft != documentScrollLeft) {
		console.log('scroll x'+ lastScrollLeft);
		lastScrollLeft = documentScrollLeft;
		$('.btn').css({'left':lastScrollLeft+'px'});
	}
});